import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-materialthings',
  templateUrl: './materialthings.component.html',
  styleUrls: ['./materialthings.component.css']
})
export class MaterialthingsComponent implements OnInit {
title="material demo";
notifications=2;
  constructor() { }

  ngOnInit(): void {
  }

}
