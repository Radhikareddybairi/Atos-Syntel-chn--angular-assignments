import { Component, OnInit } from '@angular/core';
import { ScrollService } from '../scroll.service';
@Component({
  selector: 'app-virtualscroll',
  templateUrl: './virtualscroll.component.html',
  styleUrls: ['./virtualscroll.component.css'],
  providers:[ScrollService]
})
export class VirtualscrollComponent implements OnInit {
  title = 'Angularvirtual scroll Project!';
  public albumdetails = [];
  constructor(private myscroll: ScrollService) {}
  ngOnInit() {
     this.myscroll.getData().subscribe((data) => {
        this.albumdetails = Array.from(Object.keys(data), k=>data[k]);
        console.log(this.albumdetails);
     });
  }

}
