import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent implements OnInit {

  constructor() { }
  @Input()
  parentMessage="";
  @Input()
  company="";
  @Input()
  emp:any;
  @Input()
  count=0;

  @Output()
childChanged=new EventEmitter<string>();
@Output() countChanged: EventEmitter<number> =   new EventEmitter();
increment() {
  this.count++;
  this.countChanged.emit(this.count);
}
decrement() {
  this.count--;
  this.countChanged.emit(this.count);
}
@Output()
remove=new EventEmitter<string>();

message="I am child component";

sendMessageToParent(){
  this.childChanged.emit(this.message);
  console.log("In sendMessageToParent......");
   }
 
  ngOnInit() {
  }

  
  onDelete(){
    console.log('in delete')

     this.remove.emit(this.emp);
     //this.remove.emit(this.company);
   }



}
