import { Component, OnInit } from '@angular/core';
import { trigger, state, style, transition, animate } from '@angular/animations';
@Component({
  selector: 'app-animationdemo',
  templateUrl: './animationdemo.component.html',
  styleUrls: ['./animationdemo.component.css'],
  animations: [
    trigger('myanimation',[
       state('smaller',style({
          transform : 'translateY(100px)'
       })),
       state('larger',style({
          transform : 'translateY(0px)'
       })),
       transition('smaller <=> larger',animate('300ms ease-in'))
    ])
 ]
      
   

})
export class AnimationdemoComponent implements OnInit {
  state: string = "smaller";
  animate() {
     this.state= this.state == 'larger' ? 'smaller' : 'larger';
  }
  constructor() { }

  ngOnInit(): void {
  }

}
