import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
 import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import { TwowayComponent } from './twoway/twoway.component';
import { ChangetextDirective } from './changetext.directive';
import { PipesComponent } from './pipes/pipes.component';
import { SortComponent } from './sort/sort.component';
import { SortPipe } from './sort.pipe';
import { OrderbypipePipe } from './orderbypipe.pipe';
import { GenderPipePipe } from './gender-pipe.pipe';
import { GenderLabelPipePipe } from './gender-label-pipe.pipe';
import { SdateComponent } from './sdate/sdate.component';
import { MyDateServiceService } from './my-date-service.service';
import { EmployeeComponent } from './employee/employee.component';
import { TemplateDrivenComponent } from './template-driven/template-driven.component';
import { ReactiveComponent } from './reactive/reactive.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import {ArticleComponent} from './article/article.component';
//For InMemory testing
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialthingsComponent } from './materialthings/materialthings.component';
import { MatButtonModule} from '@angular/material/button';
import {MatButtonToggleModule} from '@angular/material/button-toggle'
import {MatIconModule} from '@angular/material/icon'
import {MatBadgeModule} from '@angular/material/badge';
import { AnimationdemoComponent } from './animationdemo/animationdemo.component';
import { VirtualscrollComponent } from './virtualscroll/virtualscroll.component';
//import { TestData } from './test-data';

@NgModule({
  declarations: [
    AppComponent,
    TwowayComponent,
    ChangetextDirective,
    PipesComponent,
    SortComponent,
    SortPipe,
    OrderbypipePipe,
    GenderPipePipe,
    GenderLabelPipePipe,
    SdateComponent,
    //TemplateComponent,
   // ReactiveComponent,
    EmployeeComponent,
    TemplateDrivenComponent,
    ReactiveComponent,
    ParentComponent,
    ChildComponent,
    ArticleComponent,
    MaterialthingsComponent,
    AnimationdemoComponent,
    VirtualscrollComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    InMemoryWebApiModule,
    BrowserAnimationsModule,
   MatButtonModule,
   MatButtonToggleModule,
   MatIconModule,
   MatBadgeModule
    
  ],
  providers: [],
   bootstrap: [AppComponent]
})
export class AppModule { }
