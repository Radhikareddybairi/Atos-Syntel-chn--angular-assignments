import { GenderLabelPipePipe } from './gender-label-pipe.pipe';

describe('GenderLabelPipePipe', () => {
  it('create an instance', () => {
    const pipe = new GenderLabelPipePipe();
    expect(pipe).toBeTruthy();
  });
});
