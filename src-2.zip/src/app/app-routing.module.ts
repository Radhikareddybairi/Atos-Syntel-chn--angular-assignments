import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import {ArticleComponent} from './article/article.component';
import { TwowayComponent } from './twoway/twoway.component';
import { PipesComponent } from './pipes/pipes.component';
import { SortComponent } from './sort/sort.component';
import { SdateComponent } from './sdate/sdate.component';
import { EmployeeComponent } from './employee/employee.component';
import { TemplateDrivenComponent } from './template-driven/template-driven.component';
import { ReactiveComponent } from './reactive/reactive.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { MaterialthingsComponent } from './materialthings/materialthings.component';
import {AnimationdemoComponent} from './animationdemo/animationdemo.component';
import {VirtualscrollComponent} from './virtualscroll/virtualscroll.component';
const routes: Routes = [
  {path:"app", component:AppComponent}, 
  {path:"basics", component:TwowayComponent},
   {path:"employeecrud", component:EmployeeComponent}, 
   {path:"date", component:SdateComponent}, 
   {path:"templatedriven", component:TemplateDrivenComponent}, 
   {path:"reactive", component:ReactiveComponent}, 
   {path:"pipe", component:PipesComponent}, 
   {path:"child", component:ChildComponent},
   {path:"parent", component:ParentComponent}, 
   {path:"sort", component:SortComponent},
   {path:"http", component:ArticleComponent},
   {path:"material", component:MaterialthingsComponent},
   {path:"animations", component:AnimationdemoComponent},
   {path:"virtualscroll", component:VirtualscrollComponent},
   {path:'**', redirectTo:"basics"},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
