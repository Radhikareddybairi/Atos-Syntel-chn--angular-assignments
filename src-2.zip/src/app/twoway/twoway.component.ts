import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-twoway',
  templateUrl: './twoway.component.html',
 
  styleUrls: ['./twoway.component.css']
})

export class TwowayComponent implements OnInit {
  title='Angular Basics';
  colors=["red","green","blue","yellow","gray"]
  day=1;
  min=1;
  name={fname:'Radhika',lname:'bairi'};
  show=true;
  hide=false;
  constructor() {

    console.log("initization of twoway")
    this.title="welcome to twoway"

  }

  ngOnInit(): void {
    console.log("initialization of OnInt")
  }
  showHide()
  {
    
  }
  
  course=['java','c','devops','sql']
  trainer:string="Radhika B"
  
  col='red'
  
  show1()
  {
    alert("hi" +this.trainer)
  }
  hello()
  {
    this.trainer="training on angular"
  }
  
}
