import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SdateComponent } from './sdate.component';

describe('SdateComponent', () => {
  let component: SdateComponent;
  let fixture: ComponentFixture<SdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
