import { GenderPipePipe } from './gender-pipe.pipe';

describe('GenderPipePipe', () => {
  it('create an instance', () => {
    const pipe = new GenderPipePipe();
    expect(pipe).toBeTruthy();
  });
});
