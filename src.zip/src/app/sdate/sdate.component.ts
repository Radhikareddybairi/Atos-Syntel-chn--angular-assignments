import { Component, OnInit } from '@angular/core';
import { MyDateServiceService } from '../my-date-service.service';

@Component({
  selector: 'app-sdate',
  templateUrl: './sdate.component.html',
  styleUrls: ['./sdate.component.css'],
  providers:[MyDateServiceService]
})
export class SdateComponent implements OnInit {

  todaydate; 
  
  constructor(private myservice: MyDateServiceService) { }
  ngOnInit() { 
     this.todaydate = this.myservice.showTodayDate(); 
   
    }
}
