import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
 import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import { TwowayComponent } from './twoway/twoway.component';
import { ChangetextDirective } from './changetext.directive';
import { PipesComponent } from './pipes/pipes.component';
import { SortComponent } from './sort/sort.component';
import { SortPipe } from './sort.pipe';
import { OrderbypipePipe } from './orderbypipe.pipe';
import { GenderPipePipe } from './gender-pipe.pipe';
import { GenderLabelPipePipe } from './gender-label-pipe.pipe';
import { SdateComponent } from './sdate/sdate.component';
import { MyDateServiceService } from './my-date-service.service';
//import { TemplateComponent } from './template/template.component';
//import { ReactiveComponent } from './reactive/reactive.component';
import { EmployeeComponent } from './employee/employee.component';
import { TemplateDrivenComponent } from './template-driven/template-driven.component';
import { ReactiveComponent } from './reactive/reactive.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { ArticleComponent } from './article/article.component';

@NgModule({
  declarations: [
    AppComponent,
    TwowayComponent,
    ChangetextDirective,
    PipesComponent,
    SortComponent,
    SortPipe,
    OrderbypipePipe,
    GenderPipePipe,
    GenderLabelPipePipe,
    SdateComponent,
    //TemplateComponent,
    //ReactiveComponent,
    EmployeeComponent,
    TemplateDrivenComponent,
    ReactiveComponent,
    ParentComponent,
    ChildComponent,
    ArticleComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
    
  ],
  providers: [],
   bootstrap: [AppComponent]
})
export class AppModule { }
