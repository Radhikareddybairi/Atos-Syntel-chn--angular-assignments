import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
 import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import { TwowayComponent } from './twoway/twoway.component';
import { ChangetextDirective } from './changetext.directive';
import { PipesComponent } from './pipes/pipes.component';
@NgModule({
  declarations: [
    AppComponent,
    TwowayComponent,
    ChangetextDirective,
    PipesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
    
  ],
  providers: [],
   bootstrap: [AppComponent]
})
export class AppModule { }
