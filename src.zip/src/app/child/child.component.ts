import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent implements OnInit {

  constructor() { }
  @Input()
  parentMessage="";
  @Input()
  company="";
  @Input()
  emp:any;

  @Output()
childChanged=new EventEmitter<string>();
@Output()
remove=new EventEmitter<string>();

message="I am child component";

sendMessageToParent(){
  this.childChanged.emit(this.message);
  console.log("In sendMessageToParent......");
   }
 
  ngOnInit() {
  }

  
  onDelete(){
    console.log('in delete')

     this.remove.emit(this.emp);
     //this.remove.emit(this.company);
   }



}
