import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {
name:string="Radhika";
Company="Atos Syntel PVT LTD"
salary=63782.748;
HireDate=new Date();

  constructor() { 
    console.log("pipe demo")
  }

  ngOnInit(): void {
  }

}
