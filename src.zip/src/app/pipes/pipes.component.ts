import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {
name:string="Radhika";
Company="Atos Syntel PVT LTD"
salary=63782.748;
HireDate=new Date();
persons = [
  {
    id: 1,
    name: 'Hardik Savani',
    gender: 0,
    website: 'itsolutionstuff.com'
  },
  {
    id: 2,
    name: 'Kajal Patel',
    gender: 1,
    website: 'nicesnippets.com'
  },
  {
    id: 3,
    name: 'Harsukh Makawana',
    gender: 0,
    website: 'laracode.com'
  }
]
  constructor() { 
    console.log("pipe demo")
  }

  ngOnInit(): void {
  }

}
