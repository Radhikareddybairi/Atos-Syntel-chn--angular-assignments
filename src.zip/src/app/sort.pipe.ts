import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sort'
})
export class SortPipe implements PipeTransform {

  transform(categories: any, searchText: any): any {
    if(searchText == null) return categories;

    return categories.filter(function(sort){
      return sort.CategoryName.toLowerCase().indexOf(searchText.toLowerCase()) > -1;
    })
  }

}
