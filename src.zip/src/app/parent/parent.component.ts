import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
  message="I am Parent component";

  childMessage="";
  company="Atos Syntel Pvt Ltd";
  employee:any;
emp=[
  {id:1,name:'Divya'},{id:2,name:'Ganga'},
  {id:3,name:'Sarvari'},{id:4,name:'Yuvansh'}
]

  constructor() { }

  ngOnInit() {
  }

  deleteEmp(e: any){

    let idx = this.emp.indexOf(e);
    console.log(idx);
    this.emp.splice(idx,1);
 
 }


}
