import { Component } from '@angular/core';

import { MyDateServiceService } from './my-date-service.service';
 @Component({
   selector: 'app-root',
  templateUrl:'./app.component.html', 
  template: `
		<app-article></app-article>
             `,
  styleUrls: ['./app.component.css'] ,
  providers:[MyDateServiceService],
}) 
export class AppComponent {
  title = 'My Angular Application';
  
}
