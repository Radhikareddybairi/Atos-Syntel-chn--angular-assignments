import { Component } from '@angular/core';

 @Component({
   selector: 'app-root',
  templateUrl:'./app.component.html', 
  styleUrls: ['./app.component.css'] 
}) 
export class AppComponent {
  title = 'My Angular Application';
  course=['java','c','devops','sql']
  trainer:string="Radhika B"
  name={'fname':'Radhika','lname':'Bairi'}
  col='red'
  show()
  {
    alert("hi" +this.trainer)
  }
  hello()
  {
    this.trainer="training on angular"
  }
}
