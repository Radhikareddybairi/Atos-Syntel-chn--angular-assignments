import { OrderbypipePipe } from './orderbypipe.pipe';

describe('OrderbypipePipe', () => {
  it('create an instance', () => {
    const pipe = new OrderbypipePipe();
    expect(pipe).toBeTruthy();
  });
});
